def ft_count_lines(string: str) -> int:
    lst = string.split("\n")
    return len(lst)